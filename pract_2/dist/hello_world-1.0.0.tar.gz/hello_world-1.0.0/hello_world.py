#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 28 11:48:33 2018

@author: maro
"""

# This is a simple python program that dispaly
# "hello world" to the screen
def helloworld():
    """"display 'hello world' to the screen"""
#    print("hello world")
    return "hello world"

