from distutils.core import setup

setup(
	name	= 'hello_world',
	version = '1.0.0', 
	py_modules = ['hello_world'], 
	author	= 'maro',
	author_email = 'andriamarolahy.rabetokotany@aims-senegal.org',
	# url = ''
	description = 'A simple program to display "hello world" in the screen',
)
